# En las Cenizas — copia para GitHub Pages

Preparada el 8 de noviembre de 2026 a partir de las siete páginas guardadas el 14 de septiembre de 2026. No se ha podido descargar ni contrastar íntegramente la versión en línea actual; cualquier cambio posterior a septiembre debe comprobarse antes de sustituir la web.

## Contenido

Página principal en español, In the Ashes, Where to Buy, Reviews, FAQ, Nas Cinzas y Rule Clarifications. Se conservan textos, imágenes disponibles, galerías, estructura y estilos. Los 372 recursos de la captura se consolidan en 224 archivos únicos.

## Cambios para funcionar sin IONOS

- Enlaces internos relativos y nombres de archivos compatibles con GitHub Pages.
- Alegreya y Vesper Libre se sustituyen por Georgia; Raleway, Roboto y Open Sans por Arial/Helvetica, según disponibilidad del dispositivo.
- Dos imágenes de fondo no guardadas se sustituyen por un fondo oscuro; se omiten dos imágenes de vista previa social no disponibles.
- Se retiran los enlaces a iconos y al manifiesto del alojamiento anterior que no estaban descargados.
- El contacto abre un borrador dirigido a enlascenizas@gmail.com. La persona debe enviarlo desde su aplicación de correo. No hay envío automático ni un servidor de formularios.
- La portada es española. La página inglesa está en in-the-ashes/index.html.
- Los enlaces a tiendas, redes y servicios de terceros siguen siendo externos.

## Publicar

1. Descomprime el ZIP. Sube el contenido de esta carpeta a la raíz del repositorio, incluyendo assets y .nojekyll.
2. En el repositorio, abre Settings → Pages. Selecciona Deploy from a branch, la rama main y /(root), y guarda.
3. Prueba la URL que indique GitHub en ordenador y móvil. Comprueba navegación, galerías y contacto.
4. Para conservar enlascenizas.com, configura después Custom domain y los registros DNS que indique GitHub. Esta copia no modifica el dominio ni cancela el alojamiento actual.

Documentación oficial: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Verificación

Se han comprobado enlaces y recursos locales, eliminado dependencias de fuentes/fondos de IONOS y validado la sintaxis JavaScript. No se ha completado la revisión visual en navegador porque la herramienta se bloqueó. La copia original permanece intacta en el proyecto.
